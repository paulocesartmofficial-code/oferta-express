package com.ofertaexpress.app.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ofertaexpress.app.data.models.HistoryItem
import com.ofertaexpress.app.data.preferences.AppPreferencesDataStore
import com.ofertaexpress.app.data.repository.OfertaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class FavoritesViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = OfertaRepository()
    private val dataStore = AppPreferencesDataStore(application)

    private val _items = MutableStateFlow<List<HistoryItem>>(emptyList())
    val items: StateFlow<List<HistoryItem>> = _items.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    init {
        loadFavorites()
    }

    fun loadFavorites() {
        viewModelScope.launch {
            _isLoading.value = true
            val baseUrl = dataStore.backendUrlFlow.first()
            repository.getHistory(baseUrl, favoritesOnly = true)
                .onSuccess { list ->
                    _items.value = list
                }
                .onFailure { }
            _isLoading.value = false
        }
    }

    fun toggleFavorite(id: String) {
        viewModelScope.launch {
            val baseUrl = dataStore.backendUrlFlow.first()
            repository.toggleFavorite(baseUrl, id).onSuccess {
                loadFavorites()
            }
        }
    }
}
