package com.ofertaexpress.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ofertaexpress.app.data.models.GeneratedOffer
import com.ofertaexpress.app.ui.theme.*
import java.util.Locale

@Composable
fun ProductOfferCard(
    offer: GeneratedOffer,
    onCopyText: (String) -> Unit,
    onCopyLink: (String) -> Unit,
    onShareText: (String) -> Unit,
    onShareWithImage: (String?, String) -> Unit,
    onEditManual: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(BrandCardBg)
            .border(1.dp, BrandCardBorder, RoundedCornerShape(28.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header with Product Info & Image
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Product Image (Coil with fallback & no deformation)
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(BrandCardSubBg)
                    .border(1.dp, BrandCardBorder, RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (!offer.selectedImage.isNullOrBlank()) {
                    AsyncImage(
                        model = offer.selectedImage,
                        contentDescription = offer.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.ShoppingBag,
                        contentDescription = "Produto",
                        tint = TextMuted,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            // Title and Prices
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = offer.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextWhite,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                // Prices & Badges
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = String.format(Locale.GERMANY, "R$ %.2f", offer.currentPrice),
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = BrandOrangeHover
                    )

                    if (offer.originalPrice != null && offer.originalPrice > offer.currentPrice) {
                        Text(
                            text = String.format(Locale.GERMANY, "R$ %.2f", offer.originalPrice),
                            fontSize = 12.sp,
                            color = TextMuted,
                            textDecoration = TextDecoration.LineThrough
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (offer.discountPercentage != null && offer.discountPercentage > 0) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(BrandOrangeBg)
                                .border(0.5.dp, BrandOrangeDark, RoundedCornerShape(8.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${offer.discountPercentage}% OFF",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = BrandOrangeHover
                            )
                        }
                    }

                    if (!offer.couponCode.isNullOrBlank()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(BrandGreenBg)
                                .border(0.5.dp, BrandGreenBorder, RoundedCornerShape(8.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Cupom: ${offer.couponCode}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrandGreen
                            )
                        }
                    }
                }
            }
        }

        // WhatsApp Message Preview Box
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(BrandCardSubBg)
                .border(1.dp, BrandCardBorder, RoundedCornerShape(20.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "💬 Prévia do Texto WhatsApp",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandGreen
                )
                Text(
                    text = "Editar",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandOrangeHover,
                    modifier = Modifier.clickable { onEditManual() }
                )
            }

            Text(
                text = offer.formattedText,
                fontSize = 12.sp,
                lineHeight = 18.sp,
                color = TextWhite
            )
        }

        // Action Buttons Row 1: Copy Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { onCopyText(offer.formattedText) },
                modifier = Modifier.weight(1f).height(46.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandCardSubBg)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copiar",
                    tint = TextWhite,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "📋 Copiar Texto", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            }

            Button(
                onClick = { onCopyLink(offer.affiliateUrl) },
                modifier = Modifier.weight(1f).height(46.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandCardSubBg)
            ) {
                Icon(
                    imageVector = Icons.Default.Link,
                    contentDescription = "Link",
                    tint = BrandOrangeHover,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "🔗 Copiar Link", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BrandOrangeHover)
            }
        }

        // Action Buttons Row 2: Share Actions (Native Android Intent)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { onShareText(offer.formattedText) },
                modifier = Modifier.weight(1f).height(48.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "WhatsApp",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "🟢 Compartilhar", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.White)
            }

            Button(
                onClick = { onShareWithImage(offer.selectedImage, offer.formattedText) },
                modifier = Modifier.weight(1f).height(48.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandOrange)
            ) {
                Icon(
                    imageVector = Icons.Default.Image,
                    contentDescription = "Foto + Texto",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "🖼️ Foto + Texto", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.White)
            }
        }
    }
}
