package com.ofertaexpress.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ofertaexpress.app.ui.theme.*

enum class PipelineStep(val label: String, val stepNumber: Int) {
    VALIDATING("Validando link", 1),
    FETCHING("Buscando produto", 2),
    AFFILIATE("Preparando link", 3),
    REDACTING("Criando texto", 4),
    COMPLETE("Oferta pronta", 5)
}

@Composable
fun StepProgressIndicator(
    currentStep: PipelineStep,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(BrandCardBg)
            .border(1.dp, BrandCardBorder, RoundedCornerShape(24.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "⚡ Gerando Oferta Inteligente",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = BrandOrangeHover
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(14.dp),
                    color = BrandOrange,
                    strokeWidth = 2.dp
                )
                Text(
                    text = "${currentStep.stepNumber}/5",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted
                )
            }
        }

        // Steps Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            PipelineStep.values().forEach { step ->
                val isCompleted = step.stepNumber < currentStep.stepNumber
                val isCurrent = step == currentStep

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isCompleted -> BrandGreen
                                    isCurrent -> BrandOrange
                                    else -> BrandCardBorder
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "OK",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        } else {
                            Text(
                                text = step.stepNumber.toString(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = if (isCurrent) Color.White else TextMuted
                            )
                        }
                    }

                    Text(
                        text = step.label,
                        fontSize = 9.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                        color = if (isCurrent) BrandOrangeHover else if (isCompleted) TextWhite else TextSubtle,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
