package com.ofertaexpress.app.utils

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream

object ShareUtils {

    fun copyToClipboard(context: Context, text: String, label: String = "Oferta") {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copiado para a área de transferência!", Toast.LENGTH_SHORT).show()
    }

    fun readFromClipboard(context: Context): String? {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = clipboard.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val text = clip.getItemAt(0).text?.toString()
            if (!text.isNullOrBlank()) {
                return text.trim()
            }
        }
        return null
    }

    fun shareText(context: Context, text: String, title: String = "Compartilhar Oferta") {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }

    suspend fun shareOfferWithImage(
        context: Context,
        okHttpClient: OkHttpClient,
        imageUrl: String?,
        text: String
    ) = withContext(Dispatchers.IO) {
        if (imageUrl.isNullOrBlank()) {
            withContext(Dispatchers.Main) {
                shareText(context, text)
            }
            return@withContext
        }

        try {
            val request = Request.Builder().url(imageUrl).build()
            val response = okHttpClient.newCall(request).execute()

            if (response.isSuccessful && response.body != null) {
                val cacheDir = File(context.cacheDir, "images")
                if (!cacheDir.exists()) cacheDir.mkdirs()

                val imageFile = File(cacheDir, "oferta_shopee_${System.currentTimeMillis()}.jpg")
                val fos = FileOutputStream(imageFile)
                fos.write(response.body!!.bytes())
                fos.flush()
                fos.close()

                val uri: Uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    imageFile
                )

                withContext(Dispatchers.Main) {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "image/jpeg"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_TEXT, text)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(intent, "Compartilhar Oferta"))
                }
            } else {
                withContext(Dispatchers.Main) {
                    shareText(context, text)
                }
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                shareText(context, text)
            }
        }
    }
}
