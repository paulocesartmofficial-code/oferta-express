package com.ofertaexpress.app.data.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class HistoryItem(
    @SerialName("id") val id: String,
    @SerialName("productId") val productId: String? = null,
    @SerialName("canonicalUrl") val canonicalUrl: String,
    @SerialName("originalUrl") val originalUrl: String,
    @SerialName("affiliateUrl") val affiliateUrl: String,
    @SerialName("title") val title: String,
    @SerialName("currentPrice") val currentPrice: Double,
    @SerialName("originalPrice") val originalPrice: Double? = null,
    @SerialName("discountPercentage") val discountPercentage: Int? = null,
    @SerialName("couponCode") val couponCode: String? = null,
    @SerialName("image") val image: String? = null,
    @SerialName("images") val images: List<String> = emptyList(),
    @SerialName("generatedMessage") val generatedMessage: String,
    @SerialName("isFavorite") val isFavorite: Boolean = false,
    @SerialName("createdAt") val createdAt: String,
    @SerialName("lastProcessedAt") val lastProcessedAt: String
)

@Serializable
data class HistoryListResponse(
    @SerialName("items") val items: List<HistoryItem>
)

@Serializable
data class SaveHistoryResponse(
    @SerialName("item") val item: HistoryItem
)

@Serializable
data class GenericActionResponse(
    @SerialName("success") val success: Boolean,
    @SerialName("message") val message: String? = null
)
