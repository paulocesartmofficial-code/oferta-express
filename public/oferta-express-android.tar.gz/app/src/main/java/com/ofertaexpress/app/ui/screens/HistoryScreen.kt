package com.ofertaexpress.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ofertaexpress.app.data.api.ApiClient
import com.ofertaexpress.app.data.models.HistoryItem
import com.ofertaexpress.app.ui.theme.*
import com.ofertaexpress.app.ui.viewmodels.HistoryViewModel
import com.ofertaexpress.app.utils.ShareUtils
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun HistoryScreen(
    viewModel: HistoryViewModel,
    onRegenerate: (String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val items by viewModel.items.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandDarkBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = { Text("Buscar no histórico...", color = TextSubtle, fontSize = 13.sp) },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Buscar",
                    tint = TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedBorderColor = BrandOrange,
                unfocusedBorderColor = BrandCardBorder,
                focusedContainerColor = BrandCardBg,
                unfocusedContainerColor = BrandCardBg
            ),
            shape = RoundedCornerShape(18.dp)
        )

        if (isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = BrandOrange)
            }
        } else if (items.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Vazio",
                        tint = TextSubtle,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "Nenhuma oferta no histórico",
                        color = TextMuted,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(items, key = { it.id }) { item ->
                    HistoryItemCard(
                        item = item,
                        onCopy = { ShareUtils.copyToClipboard(context, item.generatedMessage, "Oferta Shopee") },
                        onShare = {
                            coroutineScope.launch {
                                ShareUtils.shareOfferWithImage(
                                    context,
                                    ApiClient.getOkHttpClient(),
                                    item.image,
                                    item.generatedMessage
                                )
                            }
                        },
                        onToggleFavorite = { viewModel.toggleFavorite(item.id) },
                        onDelete = { viewModel.deleteItem(item.id) },
                        onRegenerate = { onRegenerate(item.canonicalUrl) }
                    )
                }
            }
        }
    }
}

@Composable
fun HistoryItemCard(
    item: HistoryItem,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit,
    onRegenerate: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(BrandCardBg)
            .border(1.dp, BrandCardBorder, RoundedCornerShape(22.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(BrandCardSubBg),
                contentAlignment = Alignment.Center
            ) {
                if (!item.image.isNullOrBlank()) {
                    AsyncImage(
                        model = item.image,
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.ShoppingBag,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = item.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = TextWhite,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = String.format(Locale.GERMANY, "R$ %.2f", item.currentPrice),
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    color = BrandOrangeHover
                )
                Text(
                    text = item.createdAt.take(10),
                    fontSize = 10.sp,
                    color = TextSubtle
                )
            }

            IconButton(onClick = onToggleFavorite, modifier = Modifier.size(32.dp)) {
                Icon(
                    imageVector = if (item.isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = "Favorito",
                    tint = if (item.isFavorite) BrandOrangeHover else TextMuted
                )
            }
        }

        // Actions Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onCopy) {
                Text("Copiar", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            }
            TextButton(onClick = onShare) {
                Text("Compartilhar", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BrandGreen)
            }
            TextButton(onClick = onRegenerate) {
                Text("Gerar De Novo", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BrandOrangeHover)
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Excluir",
                    tint = TextSubtle,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
