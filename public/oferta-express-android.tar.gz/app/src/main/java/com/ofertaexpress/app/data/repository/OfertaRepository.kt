package com.ofertaexpress.app.data.repository

import com.ofertaexpress.app.data.api.ApiClient
import com.ofertaexpress.app.data.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class OfertaRepository {

    suspend fun checkHealth(baseUrl: String): Result<HealthResponse> = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.getService(baseUrl).checkHealth()
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("Backend offline ou resposta inválida (HTTP ${response.code()})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getSettings(baseUrl: String): Result<AppSettings> = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.getService(baseUrl).getSettings()
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!.settings)
            } else {
                Result.failure(Exception("Falha ao buscar configurações"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun testShopeeIntegration(baseUrl: String): Result<ShopeeTestResponse> = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.getService(baseUrl).testShopeeIntegration()
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("Erro na resposta de teste Shopee"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun runOfferPipeline(
        baseUrl: String,
        url: String,
        customAffiliate: String?,
        preferences: OfferPreferences?
    ): Result<PipelineOfferResponse> = withContext(Dispatchers.IO) {
        try {
            val request = PipelineOfferRequest(
                url = url,
                customAffiliate = customAffiliate,
                preferences = preferences,
                saveToHistory = true
            )
            val response = ApiClient.getService(baseUrl).runPipeline(request)
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                if (body.success && body.offer != null) {
                    Result.success(body)
                } else {
                    Result.failure(Exception(body.message ?: "Falha ao processar produto"))
                }
            } else {
                Result.failure(Exception("Erro no servidor (HTTP ${response.code()})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getHistory(baseUrl: String, favoritesOnly: Boolean = false, search: String? = null): Result<List<HistoryItem>> = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.getService(baseUrl).getHistory(
                favoritesOnly = if (favoritesOnly) true else null,
                search = if (!search.isNullOrBlank()) search else null
            )
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!.items)
            } else {
                Result.failure(Exception("Falha ao carregar histórico"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleFavorite(baseUrl: String, id: String): Result<HistoryItem> = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.getService(baseUrl).toggleFavorite(id)
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!.item)
            } else {
                Result.failure(Exception("Falha ao favoritar item"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteHistoryItem(baseUrl: String, id: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.getService(baseUrl).deleteHistoryItem(id)
            if (response.isSuccessful && response.body()?.success == true) {
                Result.success(true)
            } else {
                Result.failure(Exception("Falha ao excluir item"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
