package com.ofertaexpress.app.data.api

import com.ofertaexpress.app.data.models.*
import retrofit2.Response
import retrofit2.http.*

interface OfertaExpressApiService {

    @GET("api/health")
    suspend fun checkHealth(): Response<HealthResponse>

    @GET("api/settings")
    suspend fun getSettings(): Response<SettingsResponse>

    @POST("api/settings")
    suspend fun updateSettings(@Body request: UpdateSettingsRequest): Response<SettingsResponse>

    @GET("api/integrations/shopee/status")
    suspend fun getShopeeStatus(): Response<ShopeeStatusResponse>

    @POST("api/integrations/shopee/test")
    suspend fun testShopeeIntegration(): Response<ShopeeTestResponse>

    @POST("api/product/resolve")
    suspend fun resolveProduct(@Body request: ResolveProductRequest): Response<ResolveProductResponse>

    @POST("api/affiliate/convert")
    suspend fun convertAffiliate(@Body request: ConvertAffiliateRequest): Response<AffiliateLinkResult>

    @POST("api/offer/generate")
    suspend fun generateOffer(@Body request: GenerateOfferRequest): Response<GenerateOfferResponse>

    @POST("api/offer/pipeline")
    suspend fun runPipeline(@Body request: PipelineOfferRequest): Response<PipelineOfferResponse>

    @GET("api/history")
    suspend fun getHistory(
        @Query("range") range: String? = null,
        @Query("favoritesOnly") favoritesOnly: Boolean? = null,
        @Query("search") search: String? = null
    ): Response<HistoryListResponse>

    @POST("api/history")
    suspend fun saveHistory(@Body item: HistoryItem): Response<SaveHistoryResponse>

    @POST("api/history/{id}/favorite")
    suspend fun toggleFavorite(@Path("id") id: String): Response<SaveHistoryResponse>

    @DELETE("api/history/{id}")
    suspend fun deleteHistoryItem(@Path("id") id: String): Response<GenericActionResponse>

    @DELETE("api/history")
    suspend fun clearHistory(): Response<GenericActionResponse>
}
