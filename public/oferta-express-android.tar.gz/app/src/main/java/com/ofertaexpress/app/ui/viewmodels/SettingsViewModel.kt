package com.ofertaexpress.app.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ofertaexpress.app.data.models.AppSettings
import com.ofertaexpress.app.data.preferences.AppPreferencesDataStore
import com.ofertaexpress.app.data.repository.OfertaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

sealed class ConnectionStatus {
    object Idle : ConnectionStatus()
    object Testing : ConnectionStatus()
    data class Connected(val message: String) : ConnectionStatus()
    data class Error(val message: String) : ConnectionStatus()
}

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = OfertaRepository()
    private val dataStore = AppPreferencesDataStore(application)

    private val _backendUrl = MutableStateFlow("")
    val backendUrl: StateFlow<String> = _backendUrl.asStateFlow()

    private val _connectionStatus = MutableStateFlow<ConnectionStatus>(ConnectionStatus.Idle)
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus.asStateFlow()

    private val _appSettings = MutableStateFlow<AppSettings?>(null)
    val appSettings: StateFlow<AppSettings?> = _appSettings.asStateFlow()

    private val _selectedStyle = MutableStateFlow("direto")
    val selectedStyle: StateFlow<String> = _selectedStyle.asStateFlow()

    private val _selectedEmojis = MutableStateFlow("moderado")
    val selectedEmojis: StateFlow<String> = _selectedEmojis.asStateFlow()

    private val _customSignature = MutableStateFlow("")
    val customSignature: StateFlow<String> = _customSignature.asStateFlow()

    private val _isSaved = MutableStateFlow(false)
    val isSaved: StateFlow<Boolean> = _isSaved.asStateFlow()

    init {
        viewModelScope.launch {
            _backendUrl.value = dataStore.backendUrlFlow.first()
            _selectedStyle.value = dataStore.styleFlow.first()
            _selectedEmojis.value = dataStore.emojisFlow.first()
            _customSignature.value = dataStore.signatureFlow.first()
            testConnection()
        }
    }

    fun setBackendUrl(url: String) {
        _backendUrl.value = url
    }

    fun setStyle(style: String) {
        _selectedStyle.value = style
    }

    fun setEmojis(emojis: String) {
        _selectedEmojis.value = emojis
    }

    fun setCustomSignature(sig: String) {
        _customSignature.value = sig
    }

    fun saveSettings() {
        viewModelScope.launch {
            dataStore.saveBackendUrl(_backendUrl.value)
            dataStore.saveStyle(_selectedStyle.value)
            dataStore.saveEmojis(_selectedEmojis.value)
            dataStore.saveSignature(_customSignature.value)
            _isSaved.value = true
            kotlinx.coroutines.delay(2000)
            _isSaved.value = false
        }
    }

    fun testConnection() {
        viewModelScope.launch {
            _connectionStatus.value = ConnectionStatus.Testing
            val url = _backendUrl.value.ifBlank { "https://meu-backend.run.app" }
            repository.checkHealth(url).onSuccess { health ->
                _connectionStatus.value = ConnectionStatus.Connected("Servidor online e respondendo.")
                health.settings?.let { _appSettings.value = it }
            }.onFailure { error ->
                _connectionStatus.value = ConnectionStatus.Error(
                    error.message ?: "Não foi possível conectar ao backend."
                )
            }
        }
    }
}
