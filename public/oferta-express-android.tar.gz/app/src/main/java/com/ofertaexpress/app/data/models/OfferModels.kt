package com.ofertaexpress.app.data.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class OfferPreferences(
    @SerialName("style") val style: String = "direto",
    @SerialName("emojis") val emojis: String = "moderado",
    @SerialName("includeRating") val includeRating: Boolean = true,
    @SerialName("includeDiscount") val includeDiscount: Boolean = true,
    @SerialName("includeCoupon") val includeCoupon: Boolean = true,
    @SerialName("includePreviousPrice") val includePreviousPrice: Boolean = true,
    @SerialName("includeDisclaimer") val includeDisclaimer: Boolean = true,
    @SerialName("customSignature") val customSignature: String? = null
)

@Serializable
data class GenerateOfferRequest(
    @SerialName("product") val product: ProductData,
    @SerialName("affiliateUrl") val affiliateUrl: String,
    @SerialName("preferences") val preferences: OfferPreferences? = null
)

@Serializable
data class GeneratedOffer(
    @SerialName("formattedText") val formattedText: String,
    @SerialName("title") val title: String,
    @SerialName("currentPrice") val currentPrice: Double,
    @SerialName("originalPrice") val originalPrice: Double? = null,
    @SerialName("discountPercentage") val discountPercentage: Int? = null,
    @SerialName("couponCode") val couponCode: String? = null,
    @SerialName("affiliateUrl") val affiliateUrl: String,
    @SerialName("selectedImage") val selectedImage: String? = null,
    @SerialName("isAiGenerated") val isAiGenerated: Boolean = false,
    @SerialName("generatedAt") val generatedAt: String? = null
)

@Serializable
data class GenerateOfferResponse(
    @SerialName("success") val success: Boolean,
    @SerialName("data") val data: GeneratedOffer? = null,
    @SerialName("message") val message: String? = null
)

@Serializable
data class PipelineOfferRequest(
    @SerialName("url") val url: String,
    @SerialName("customAffiliate") val customAffiliate: String? = null,
    @SerialName("preferences") val preferences: OfferPreferences? = null,
    @SerialName("saveToHistory") val saveToHistory: Boolean = true
)

@Serializable
data class PipelineOfferResponse(
    @SerialName("success") val success: Boolean,
    @SerialName("product") val product: ProductData? = null,
    @SerialName("affiliate") val affiliate: AffiliateLinkResult? = null,
    @SerialName("offer") val offer: GeneratedOffer? = null,
    @SerialName("historyItem") val historyItem: HistoryItem? = null,
    @SerialName("message") val message: String? = null
)
