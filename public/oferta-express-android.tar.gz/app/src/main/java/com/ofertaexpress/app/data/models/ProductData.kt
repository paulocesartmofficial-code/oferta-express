package com.ofertaexpress.app.data.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ProductData(
    @SerialName("source") val source: String = "shopee_resolver",
    @SerialName("productId") val productId: String? = null,
    @SerialName("canonicalUrl") val canonicalUrl: String,
    @SerialName("title") val title: String,
    @SerialName("currentPrice") val currentPrice: Double,
    @SerialName("originalPrice") val originalPrice: Double? = null,
    @SerialName("discountPercentage") val discountPercentage: Int? = null,
    @SerialName("couponCode") val couponCode: String? = null,
    @SerialName("rating") val rating: Double? = null,
    @SerialName("salesCount") val salesCount: String? = null,
    @SerialName("image") val image: String? = null,
    @SerialName("images") val images: List<String> = emptyList(),
    @SerialName("description") val description: String? = null,
    @SerialName("fetchedAt") val fetchedAt: String? = null
)

@Serializable
data class ResolveProductRequest(
    @SerialName("url") val url: String
)

@Serializable
data class ResolveProductResponse(
    @SerialName("success") val success: Boolean,
    @SerialName("data") val data: ProductData? = null,
    @SerialName("message") val message: String? = null
)
