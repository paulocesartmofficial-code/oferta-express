package com.ofertaexpress.app.utils

import java.net.URI

object UrlValidator {

    data class ValidationResult(
        val isValid: Boolean,
        val cleanUrl: String = "",
        val isShortLink: Boolean = false,
        val isAffiliateLink: Boolean = false,
        val errorMessage: String? = null
    )

    fun validateShopeeUrl(rawUrl: String): ValidationResult {
        val trimmed = rawUrl.trim()
        if (trimmed.isBlank()) {
            return ValidationResult(
                isValid = false,
                errorMessage = "Por favor, insira um link da Shopee."
            )
        }

        // Add https if missing
        val formatted = if (!trimmed.startsWith("http://", ignoreCase = true) &&
            !trimmed.startsWith("https://", ignoreCase = true)
        ) {
            "https://$trimmed"
        } else {
            trimmed
        }

        return try {
            val uri = URI(formatted)
            val host = uri.host?.lowercase() ?: ""

            val isShopeeDomain = host.endsWith("shopee.com.br") ||
                    host.endsWith("shopee.com") ||
                    host == "s.shopee.com.br" ||
                    host.contains("shope.ee")

            if (!isShopeeDomain) {
                return ValidationResult(
                    isValid = false,
                    errorMessage = "O link deve pertencer ao domínio Shopee (ex: shopee.com.br ou s.shopee.com.br)."
                )
            }

            val isShortLink = host.startsWith("s.") || host.contains("shope.ee")
            val isAffiliate = isShortLink || formatted.contains("utm_campaign") || formatted.contains("affiliate")

            ValidationResult(
                isValid = true,
                cleanUrl = formatted,
                isShortLink = isShortLink,
                isAffiliateLink = isAffiliate
            )
        } catch (e: Exception) {
            ValidationResult(
                isValid = false,
                errorMessage = "Formato de URL inválido."
            )
        }
    }
}
