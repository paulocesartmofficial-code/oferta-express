package com.ofertaexpress.app.ui.screens

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ofertaexpress.app.data.api.ApiClient
import com.ofertaexpress.app.data.models.ProductData
import com.ofertaexpress.app.ui.components.*
import com.ofertaexpress.app.ui.theme.*
import com.ofertaexpress.app.ui.viewmodels.HomeUiState
import com.ofertaexpress.app.ui.viewmodels.HomeViewModel
import com.ofertaexpress.app.utils.ShareUtils
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNavigateToBatch: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val uiState by viewModel.uiState.collectAsState()
    val inputUrl by viewModel.inputUrl.collectAsState()
    val customAffiliate by viewModel.customAffiliate.collectAsState()
    val showCustomAffiliate by viewModel.showCustomAffiliate.collectAsState()

    var isManualOpen by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandDarkBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Main Link Input Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(BrandCardBg)
                .border(1.dp, BrandCardBorder, RoundedCornerShape(28.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header with Batch mode switcher
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "COLE O LINK DO PRODUTO SHOPEE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = TextMuted,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "shopee.com.br ou s.shopee.com.br",
                        fontSize = 11.sp,
                        color = TextSubtle
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(BrandOrangeBg)
                        .border(1.dp, BrandOrangeDark, RoundedCornerShape(16.dp))
                        .clickable { onNavigateToBatch() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = "Lote",
                            tint = BrandOrangeHover,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Modo Lote",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandOrangeHover
                        )
                    }
                }
            }

            // Input Field with Paste & Clear buttons
            OutlinedTextField(
                value = inputUrl,
                onValueChange = { viewModel.setInputUrl(it) },
                placeholder = { Text("https://shopee.com.br/...", color = TextSubtle, fontSize = 13.sp) },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = "Link",
                        tint = BrandOrangeHover,
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        if (inputUrl.isNotBlank()) {
                            IconButton(onClick = { viewModel.setInputUrl("") }, modifier = Modifier.size(28.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Limpar",
                                    tint = TextMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        // Native Clipboard Paste Button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(BrandCardSubBg)
                                .border(1.dp, BrandCardBorder, RoundedCornerShape(10.dp))
                                .clickable {
                                    val pasted = ShareUtils.readFromClipboard(context)
                                    if (!pasted.isNullOrBlank()) {
                                        viewModel.setInputUrl(pasted)
                                    }
                                }
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentPaste,
                                    contentDescription = "Colar",
                                    tint = TextWhite,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "Colar",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            }
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite,
                    focusedBorderColor = BrandOrange,
                    unfocusedBorderColor = BrandCardBorder,
                    focusedContainerColor = BrandCardSubBg,
                    unfocusedContainerColor = BrandCardSubBg
                ),
                shape = RoundedCornerShape(18.dp)
            )

            // Optional Custom Affiliate Link Accordion
            Column {
                Row(
                    modifier = Modifier
                        .clickable { viewModel.toggleCustomAffiliate() }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalOffer,
                        contentDescription = "Afiliado",
                        tint = BrandOrangeHover,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Já tenho um link de afiliado específico",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )
                    Icon(
                        imageVector = if (showCustomAffiliate) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Toggle",
                        tint = TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }

                if (showCustomAffiliate) {
                    OutlinedTextField(
                        value = customAffiliate,
                        onValueChange = { viewModel.setCustomAffiliate(it) },
                        placeholder = { Text("https://s.shopee.com.br/...", color = TextSubtle, fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = BrandOrange,
                            unfocusedBorderColor = BrandCardBorder,
                            focusedContainerColor = BrandCardSubBg,
                            unfocusedContainerColor = BrandCardSubBg
                        ),
                        shape = RoundedCornerShape(14.dp)
                    )
                }
            }

            // Generate Button
            Button(
                onClick = { viewModel.generateOffer(inputUrl) },
                enabled = inputUrl.isNotBlank() && uiState !is HomeUiState.Processing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandOrange,
                    disabledContainerColor = BrandOrange.copy(alpha = 0.4f)
                )
            ) {
                Text(
                    text = "🔥 GERAR OFERTA",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
            }

            // Assisted Manual Link
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.clickable { isManualOpen = true },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Manual",
                        tint = BrandOrangeHover,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Preenchimento Manual Assistido",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandOrangeHover
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Seguro",
                        tint = BrandGreen,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = "Link Seguro",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }
        }

        // Processing State
        if (uiState is HomeUiState.Processing) {
            val step = (uiState as HomeUiState.Processing).step
            StepProgressIndicator(currentStep = step)
        }

        // Error State
        if (uiState is HomeUiState.Error) {
            val msg = (uiState as HomeUiState.Error).message
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(BrandRedBg)
                    .border(1.dp, BrandRedBorder, RoundedCornerShape(20.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = "Erro", tint = BrandRed)
                    Text(text = msg, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "Ajustar URL do Backend",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandOrangeHover,
                        modifier = Modifier.clickable { onNavigateToSettings() }
                    )
                }
            }
        }

        // Success Result Card
        if (uiState is HomeUiState.Success) {
            val offer = (uiState as HomeUiState.Success).offer
            ProductOfferCard(
                offer = offer,
                onCopyText = { ShareUtils.copyToClipboard(context, it, "Oferta Shopee") },
                onCopyLink = { ShareUtils.copyToClipboard(context, it, "Link Shopee") },
                onShareText = { ShareUtils.shareText(context, it) },
                onShareWithImage = { img, txt ->
                    coroutineScope.launch {
                        ShareUtils.shareOfferWithImage(context, ApiClient.getOkHttpClient(), img, txt)
                    }
                },
                onEditManual = { isManualOpen = true }
            )
        }
    }

    // Manual Dialog
    if (isManualOpen) {
        AssistedManualDialog(
            initialAffiliateUrl = inputUrl,
            onDismiss = { isManualOpen = false },
            onConfirm = { product, affUrl ->
                isManualOpen = false
                viewModel.generateOffer(affUrl, affUrl)
            }
        )
    }
}
