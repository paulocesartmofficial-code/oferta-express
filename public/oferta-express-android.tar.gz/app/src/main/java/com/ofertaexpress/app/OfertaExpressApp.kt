package com.ofertaexpress.app

import android.app.Application

class OfertaExpressApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // No hardcoded secrets, clean initialization
    }
}
