package com.ofertaexpress.app.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = BrandOrange,
    onPrimary = TextWhite,
    primaryContainer = BrandOrangeDark,
    onPrimaryContainer = TextWhite,
    secondary = BrandGreen,
    onSecondary = TextWhite,
    background = BrandDarkBg,
    onBackground = TextWhite,
    surface = BrandCardBg,
    onSurface = TextWhite,
    surfaceVariant = BrandCardSubBg,
    onSurfaceVariant = TextMuted,
    outline = BrandCardBorder
)

@Composable
fun OfertaExpressTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = BrandDarkBg.toArgb()
            window.navigationBarColor = BrandDarkBg.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
