package com.ofertaexpress.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.ofertaexpress.app.data.models.ProductData
import com.ofertaexpress.app.ui.theme.*

@Composable
fun AssistedManualDialog(
    initialTitle: String = "",
    initialPrice: Double = 0.0,
    initialOriginalPrice: Double? = null,
    initialAffiliateUrl: String = "",
    initialCoupon: String = "",
    onDismiss: () -> Unit,
    onConfirm: (ProductData, String) -> Unit
) {
    var title by remember { mutableStateOf(initialTitle) }
    var priceText by remember { mutableStateOf(if (initialPrice > 0) initialPrice.toString() else "") }
    var originalPriceText by remember { mutableStateOf(initialOriginalPrice?.toString() ?: "") }
    var affiliateUrl by remember { mutableStateOf(initialAffiliateUrl) }
    var couponCode by remember { mutableStateOf(initialCoupon) }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(BrandCardBg)
                .border(1.dp, BrandCardBorder, RoundedCornerShape(28.dp))
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Manual",
                        tint = BrandOrangeHover,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Preenchimento Manual",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = TextWhite
                    )
                }

                IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Fechar",
                        tint = TextMuted
                    )
                }
            }

            // Title field
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Nome / Título do Produto", color = TextMuted, fontSize = 12.sp) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite,
                    focusedBorderColor = BrandOrange,
                    unfocusedBorderColor = BrandCardBorder
                ),
                shape = RoundedCornerShape(16.dp)
            )

            // Price field
            OutlinedTextField(
                value = priceText,
                onValueChange = { priceText = it },
                label = { Text("Preço Atual (R$)", color = TextMuted, fontSize = 12.sp) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite,
                    focusedBorderColor = BrandOrange,
                    unfocusedBorderColor = BrandCardBorder
                ),
                shape = RoundedCornerShape(16.dp)
            )

            // Original Price field
            OutlinedTextField(
                value = originalPriceText,
                onValueChange = { originalPriceText = it },
                label = { Text("Preço Anterior (R$) - Opcional", color = TextMuted, fontSize = 12.sp) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite,
                    focusedBorderColor = BrandOrange,
                    unfocusedBorderColor = BrandCardBorder
                ),
                shape = RoundedCornerShape(16.dp)
            )

            // Affiliate link
            OutlinedTextField(
                value = affiliateUrl,
                onValueChange = { affiliateUrl = it },
                label = { Text("Link de Afiliado (s.shopee.com.br)", color = TextMuted, fontSize = 12.sp) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite,
                    focusedBorderColor = BrandOrange,
                    unfocusedBorderColor = BrandCardBorder
                ),
                shape = RoundedCornerShape(16.dp)
            )

            // Coupon
            OutlinedTextField(
                value = couponCode,
                onValueChange = { couponCode = it },
                label = { Text("Cupom de Desconto - Opcional", color = TextMuted, fontSize = 12.sp) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite,
                    focusedBorderColor = BrandOrange,
                    unfocusedBorderColor = BrandCardBorder
                ),
                shape = RoundedCornerShape(16.dp)
            )

            // Confirm button
            Button(
                onClick = {
                    val curPrice = priceText.replace(",", ".").toDoubleOrNull() ?: 0.0
                    val origPrice = originalPriceText.replace(",", ".").toDoubleOrNull()
                    val discount = if (origPrice != null && origPrice > curPrice) {
                        (((origPrice - curPrice) / origPrice) * 100).toInt()
                    } else null

                    val product = ProductData(
                        source = "manual",
                        canonicalUrl = affiliateUrl.ifBlank { "https://shopee.com.br" },
                        title = title.ifBlank { "Produto Shopee" },
                        currentPrice = curPrice,
                        originalPrice = origPrice,
                        discountPercentage = discount,
                        couponCode = couponCode.ifBlank { null }
                    )
                    onConfirm(product, affiliateUrl.ifBlank { "https://shopee.com.br" })
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandOrange)
            ) {
                Text("🔥 GERAR COM DADOS MANUAIS", fontWeight = FontWeight.Black, fontSize = 13.sp, color = Color.White)
            }
        }
    }
}
