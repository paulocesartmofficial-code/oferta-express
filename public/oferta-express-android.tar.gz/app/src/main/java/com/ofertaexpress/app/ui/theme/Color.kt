package com.ofertaexpress.app.ui.theme

import androidx.compose.ui.graphics.Color

val BrandDarkBg = Color(0xFF020617)       // Deep slate 950
val BrandCardBg = Color(0xFF0F172A)       // Slate 900
val BrandCardBorder = Color(0xFF1E293B)   // Slate 800
val BrandCardSubBg = Color(0xFF0B1120)    // Slate 950/70

val BrandOrange = Color(0xFFEA580C)       // Shopee Orange primary
val BrandOrangeHover = Color(0xFFF97316)  // Shopee Orange light
val BrandOrangeDark = Color(0xFF9A3412)   // Shopee Orange deep
val BrandOrangeBg = Color(0xFF431407)     // Orange badge bg

val BrandGreen = Color(0xFF22C55E)        // Active / connected green
val BrandGreenBg = Color(0xFF052E16)      // Green badge bg
val BrandGreenBorder = Color(0xFF14532D)

val BrandBlue = Color(0xFF38BDF8)         // AI ready blue
val BrandBlueBg = Color(0xFF082F49)
val BrandBlueBorder = Color(0xFF0369A1)

val BrandRed = Color(0xFFEF4444)
val BrandRedBg = Color(0xFF450A0A)
val BrandRedBorder = Color(0xFF7F1D1D)

val TextWhite = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF94A3B8)
val TextSubtle = Color(0xFF64748B)
