package com.ofertaexpress.app.data.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ConvertAffiliateRequest(
    @SerialName("url") val url: String,
    @SerialName("customAffiliate") val customAffiliate: String? = null
)

@Serializable
data class AffiliateLinkResult(
    @SerialName("success") val success: Boolean,
    @SerialName("affiliateUrl") val affiliateUrl: String,
    @SerialName("isPreserved") val isPreserved: Boolean = false,
    @SerialName("method") val method: String? = null,
    @SerialName("reason") val reason: String? = null
)

@Serializable
data class ShopeeStatusResponse(
    @SerialName("isConfigured") val isConfigured: Boolean,
    @SerialName("integrationType") val integrationType: String,
    @SerialName("description") val description: String
)

@Serializable
data class ShopeeTestResponse(
    @SerialName("success") val success: Boolean,
    @SerialName("status") val status: String,
    @SerialName("message") val message: String
)
