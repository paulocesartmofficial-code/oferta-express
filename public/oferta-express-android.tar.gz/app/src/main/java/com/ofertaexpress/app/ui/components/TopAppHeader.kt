package com.ofertaexpress.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ofertaexpress.app.ui.theme.*

@Composable
fun TopAppHeader(
    isOnline: Boolean = true,
    affiliateConfigured: Boolean = false,
    geminiReady: Boolean = true
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(BrandCardBg.copy(alpha = 0.95f))
            .border(width = 1.dp, color = BrandCardBorder)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Logo & Title
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(BrandOrange),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LocalFireDepartment,
                    contentDescription = "Oferta Express",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "OFERTA EXPRESS",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = TextWhite,
                        letterSpacing = (-0.5).sp
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(BrandOrangeBg)
                            .border(0.5.dp, BrandOrangeDark, RoundedCornerShape(4.dp))
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "SHOPEE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            color = BrandOrangeHover
                        )
                    }
                }
                Text(
                    text = "GERADOR DE OFERTAS SHOPEE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandOrangeHover,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // Right Status Badges
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Status Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (affiliateConfigured) BrandGreenBg else BrandCardBorder)
                    .border(
                        1.dp,
                        if (affiliateConfigured) BrandGreenBorder else BrandCardBorder,
                        RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (affiliateConfigured) BrandGreen else Color(0xFFFBBF24))
                    )
                    Text(
                        text = if (affiliateConfigured) "Afiliado Ativo" else "Pronto",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (affiliateConfigured) BrandGreen else TextMuted
                    )
                }
            }

            if (geminiReady) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(BrandBlueBg)
                        .border(1.dp, BrandBlueBorder, RoundedCornerShape(16.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "IA",
                            tint = BrandBlue,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "IA Pronta",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandBlue
                        )
                    }
                }
            }
        }
    }
}
