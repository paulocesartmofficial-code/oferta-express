package com.ofertaexpress.app.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "oferta_express_prefs")

class AppPreferencesDataStore(private val context: Context) {

    companion object {
        val BACKEND_URL_KEY = stringPreferencesKey("backend_url")
        val STYLE_KEY = stringPreferencesKey("pref_style")
        val EMOJIS_KEY = stringPreferencesKey("pref_emojis")
        val INCLUDE_RATING_KEY = booleanPreferencesKey("pref_include_rating")
        val INCLUDE_DISCOUNT_KEY = booleanPreferencesKey("pref_include_discount")
        val INCLUDE_COUPON_KEY = booleanPreferencesKey("pref_include_coupon")
        val INCLUDE_PREVIOUS_PRICE_KEY = booleanPreferencesKey("pref_include_prev_price")
        val INCLUDE_DISCLAIMER_KEY = booleanPreferencesKey("pref_include_disclaimer")
        val CUSTOM_SIGNATURE_KEY = stringPreferencesKey("pref_custom_signature")
    }

    val backendUrlFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[BACKEND_URL_KEY] ?: "https://meu-backend.run.app"
    }

    suspend fun saveBackendUrl(url: String) {
        context.dataStore.edit { preferences ->
            preferences[BACKEND_URL_KEY] = url.trim()
        }
    }

    val styleFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[STYLE_KEY] ?: "direto"
    }

    suspend fun saveStyle(style: String) {
        context.dataStore.edit { preferences ->
            preferences[STYLE_KEY] = style
        }
    }

    val emojisFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[EMOJIS_KEY] ?: "moderado"
    }

    suspend fun saveEmojis(emojis: String) {
        context.dataStore.edit { preferences ->
            preferences[EMOJIS_KEY] = emojis
        }
    }

    val signatureFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[CUSTOM_SIGNATURE_KEY] ?: ""
    }

    suspend fun saveSignature(signature: String) {
        context.dataStore.edit { preferences ->
            preferences[CUSTOM_SIGNATURE_KEY] = signature
        }
    }
}
