package com.ofertaexpress.app.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ofertaexpress.app.data.models.GeneratedOffer
import com.ofertaexpress.app.data.models.OfferPreferences
import com.ofertaexpress.app.data.models.ProductData
import com.ofertaexpress.app.data.preferences.AppPreferencesDataStore
import com.ofertaexpress.app.data.repository.OfertaRepository
import com.ofertaexpress.app.ui.components.PipelineStep
import com.ofertaexpress.app.utils.UrlValidator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

sealed class HomeUiState {
    object Idle : HomeUiState()
    data class Processing(val step: PipelineStep) : HomeUiState()
    data class Success(val offer: GeneratedOffer) : HomeUiState()
    data class Error(val message: String) : HomeUiState()
}

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = OfertaRepository()
    private val dataStore = AppPreferencesDataStore(application)

    private val _uiState = MutableStateFlow<HomeUiState>(HomeUiState.Idle)
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _inputUrl = MutableStateFlow("")
    val inputUrl: StateFlow<String> = _inputUrl.asStateFlow()

    private val _customAffiliate = MutableStateFlow("")
    val customAffiliate: StateFlow<String> = _customAffiliate.asStateFlow()

    private val _showCustomAffiliate = MutableStateFlow(false)
    val showCustomAffiliate: StateFlow<Boolean> = _showCustomAffiliate.asStateFlow()

    private val _isOnline = MutableStateFlow(true)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    private val _affiliateConfigured = MutableStateFlow(false)
    val affiliateConfigured: StateFlow<Boolean> = _affiliateConfigured.asStateFlow()

    private val _geminiReady = MutableStateFlow(true)
    val geminiReady: StateFlow<Boolean> = _geminiReady.asStateFlow()

    init {
        fetchStatus()
    }

    fun setInputUrl(url: String) {
        _inputUrl.value = url
    }

    fun setCustomAffiliate(url: String) {
        _customAffiliate.value = url
    }

    fun toggleCustomAffiliate() {
        _showCustomAffiliate.value = !_showCustomAffiliate.value
    }

    fun fetchStatus() {
        viewModelScope.launch {
            val baseUrl = dataStore.backendUrlFlow.first()
            repository.getSettings(baseUrl).onSuccess { settings ->
                _affiliateConfigured.value = settings.affiliateConfigured
                _geminiReady.value = settings.hasGeminiKey
            }.onFailure {
                // If offline or unreachable
            }
        }
    }

    fun generateOffer(rawUrl: String, customAff: String? = null) {
        val validation = UrlValidator.validateShopeeUrl(rawUrl)
        if (!validation.isValid) {
            _uiState.value = HomeUiState.Error(validation.errorMessage ?: "Link inválido.")
            return
        }

        viewModelScope.launch {
            val baseUrl = dataStore.backendUrlFlow.first()
            val style = dataStore.styleFlow.first()
            val emojis = dataStore.emojisFlow.first()
            val signature = dataStore.signatureFlow.first()

            val prefs = OfferPreferences(
                style = style,
                emojis = emojis,
                customSignature = signature.ifBlank { null }
            )

            _uiState.value = HomeUiState.Processing(PipelineStep.VALIDATING)

            kotlinx.coroutines.delay(200)
            _uiState.value = HomeUiState.Processing(PipelineStep.FETCHING)

            kotlinx.coroutines.delay(200)
            _uiState.value = HomeUiState.Processing(PipelineStep.AFFILIATE)

            val result = repository.runOfferPipeline(
                baseUrl = baseUrl,
                url = validation.cleanUrl,
                customAffiliate = if (!customAff.isNullOrBlank()) customAff else _customAffiliate.value.ifBlank { null },
                preferences = prefs
            )

            result.onSuccess { response ->
                _uiState.value = HomeUiState.Processing(PipelineStep.REDACTING)
                kotlinx.coroutines.delay(200)
                _uiState.value = HomeUiState.Processing(PipelineStep.COMPLETE)
                kotlinx.coroutines.delay(150)
                _uiState.value = HomeUiState.Success(response.offer!!)
            }.onFailure { error ->
                _uiState.value = HomeUiState.Error(
                    error.message ?: "Erro ao conectar ao backend. Verifique a URL em Configurações."
                )
            }
        }
    }

    fun resetState() {
        _uiState.value = HomeUiState.Idle
    }
}
