package com.ofertaexpress.app.data.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class AppSettings(
    @SerialName("defaultPreferences") val defaultPreferences: OfferPreferences = OfferPreferences(),
    @SerialName("affiliateConfigured") val affiliateConfigured: Boolean = false,
    @SerialName("affiliateIntegrationType") val affiliateIntegrationType: String = "unconfigured",
    @SerialName("shopeeAppIdPreview") val shopeeAppIdPreview: String? = null,
    @SerialName("hasGeminiKey") val hasGeminiKey: Boolean = false
)

@Serializable
data class SettingsResponse(
    @SerialName("settings") val settings: AppSettings
)

@Serializable
data class UpdateSettingsRequest(
    @SerialName("defaultPreferences") val defaultPreferences: OfferPreferences? = null
)

@Serializable
data class HealthResponse(
    @SerialName("status") val status: String,
    @SerialName("service") val service: String? = null,
    @SerialName("settings") val settings: AppSettings? = null
)
