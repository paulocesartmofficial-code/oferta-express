package com.ofertaexpress.app.data.api

import com.ofertaexpress.app.data.models.*
import retrofit2.http.*

interface OfertaExpressApiService {

    @GET("api/health")
    async suspend fun healthCheck(): HealthCheckResponse

    @POST("api/product/resolve")
    async suspend fun resolveProduct(@Body request: ResolveProductRequest): ResolveProductResponse

    @POST("api/affiliate/convert")
    async suspend fun convertAffiliate(@Body request: ConvertAffiliateRequest): ConvertAffiliateResponse

    @POST("api/offer/generate")
    async suspend fun generateOffer(@Body request: GenerateOfferRequest): GeneratedOffer

    @POST("api/offer/pipeline")
    async suspend fun runPipeline(@Body request: PipelineOfferRequest): PipelineOfferResponse

    @GET("api/history")
    async suspend fun getHistory(
        @Query("range") range: String? = null,
        @Query("favoritesOnly") favoritesOnly: Boolean? = null,
        @Query("search") search: String? = null
    ): HistoryListResponse

    @POST("api/history")
    async suspend fun saveHistory(@Body item: HistoryItem): Map<String, HistoryItem>

    @POST("api/history/{id}/favorite")
    async suspend fun toggleFavorite(@Path("id") id: String): FavoriteToggleResponse

    @DELETE("api/history/{id}")
    async suspend fun deleteHistory(@Path("id") id: String): Map<String, Boolean>

    @GET("api/settings")
    async suspend fun getSettings(): SettingsResponse

    @POST("api/settings")
    async suspend fun updateSettings(@Body settings: AppSettings): SettingsResponse
}
